package com.capg.flp.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;



@Controller
public class MerchantFrontController {
	
	@RequestMapping(value="/homepage", method=RequestMethod.GET)
	public String updateM()
	{
		return "merchant";
	}
	
	@RequestMapping(value="/add", method=RequestMethod.GET)
	public String add()
	{
		return "addproduct";
	}
	@RequestMapping(value="/rem", method=RequestMethod.GET)
	public String remove()
	{
		return "remove";
	}
	@RequestMapping(value="/profile", method=RequestMethod.GET)
	public String profile()
	{
		return "changeprofile";
	}
	@RequestMapping(value="/pass", method=RequestMethod.GET)
	public String pass_word()
	{
		return "changepassword";
	}

}

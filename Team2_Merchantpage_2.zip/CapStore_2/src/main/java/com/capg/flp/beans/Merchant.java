package com.capg.flp.beans;

public class Merchant {
	private int m_id;
	private String username;
	private String password;
	private String Status;
	private String m_type;

	public int getM_id() {
		return m_id;
	}

	public void setM_id(int m_id) {
		this.m_id = m_id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Merchant() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getStatus() {
		return Status;
	}

	public void setStatus(String status) {
		Status = status;
	}

	public Merchant(int m_id, String username, String password, String status, String m_type) {
		super();
		this.m_id = m_id;
		this.username = username;
		this.password = password;
		Status = status;
		this.m_type = m_type;
	}

	public String getM_type() {
		return m_type;
	}

	public void setM_type(String m_type) {
		this.m_type = m_type;
	}

}

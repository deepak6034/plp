package com.capg.flp.CapStore_2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages="com.capg.flp")
public class CapStore2Application {

	public static void main(String[] args) {
		SpringApplication.run(CapStore2Application.class, args);
	}
}

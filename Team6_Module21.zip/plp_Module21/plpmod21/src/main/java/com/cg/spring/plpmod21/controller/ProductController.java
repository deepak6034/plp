package com.cg.spring.plpmod21.controller;

import java.math.BigDecimal;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.spring.plpmod21.beans.Cart;
import com.cg.spring.plpmod21.beans.Product;
import com.cg.spring.plpmod21.service.CartService;
//import com.cg.spring.plpmod21.service.CartService;
import com.cg.spring.plpmod21.service.ProductService;

@Controller
public class ProductController {
	int ct,count = 1;
	//static Cart c;
	@Autowired
	ProductService service;
	@Autowired
	CartService serviceCart;
	
	@RequestMapping("/demoo")
	public String showProductByIdPage() {
		return "demoo";
	}

	@RequestMapping(value = "/products", method = RequestMethod.GET)
	public ModelAndView getProducts() {
		Iterable<Product> p1 = service.getAllProducts();
		return new ModelAndView("index", "prod", p1);
	}

	@RequestMapping(value = "/carting/{p_id}", method = RequestMethod.GET)
	public String cartProducts(@PathVariable("p_id") int p_id) {
		Optional<Product> prod = service.getProdById(p_id);
		Iterable<Cart> list = serviceCart.getCartProducts();
		Product pro = prod.get();
		for (Cart cart : list) {
			
			if(cart.getP_id()==p_id) {
				System.out.println("enteringggggggggg");
				//c=serviceCart.getCartProductById(cart.getC_id()).get();
				count=cart.getP_quantity();
				count++;
				cart.setP_quantity(count);
				BigDecimal amount = cart.getCartAmount();
				cart.setCartAmount(amount.add(pro.getP_price()));
				serviceCart.updateCart(cart);
				return "redirect:/showall";
			}
			
		}
		
			System.out.println("elseeeeeeeeeeeeeeee");
		Cart c1 = new Cart();
		c1.setP_id(p_id);
		c1.setP_name(pro.getP_name());
		c1.setCartAmount(pro.getP_price());
		c1.setP_quantity(1);
		serviceCart.addToCart(c1);
		return "redirect:/showall";
	}
	
	@RequestMapping(value = "/showall", method = RequestMethod.GET)
	public ModelAndView showAllCartProducts() {
		Iterable<Cart> li = serviceCart.getCartProducts();
		return new ModelAndView("cart", "cartProd", li);
	}
	
	@RequestMapping(value = "/delete/{p_id}", method = RequestMethod.GET)
	public String deleteCartProduct(@PathVariable("p_id") int p_id) {
		Iterable<Cart> list = serviceCart.getCartProducts();
		for (Cart cart : list) {
			if(cart.getP_id()==p_id) {
				int id = cart.getC_id();
				serviceCart.deleteFromCart(id);
				return "success";
			}
		}
		return "failed";
		
	}
}

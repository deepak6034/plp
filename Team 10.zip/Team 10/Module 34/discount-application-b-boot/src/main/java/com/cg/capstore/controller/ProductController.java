package com.cg.capstore.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.cg.capstore.bean.Products;
import com.cg.capstore.service.ProductService;

@RestController
public class ProductController {

	@Autowired
	ProductService service;

	@RequestMapping("/getProducts")
	public List<Products> getAll() {

		List<Products> list = service.findAll();
		Products p = service.findAll().iterator().next();
		
		//p.setDiscount_price(a);

		for (int i = 0; i < list.size(); i++) {
			Products pr = list.get(i);
			float b = pr.getP_price();
			int c = pr.getDiscount();
			int d = pr.getQuantity();
			float a;
			float e;
			e = (b * (100 - c) * d);
			a = e / 100;
			pr.setDiscount_price(a);
			list.set(i, pr);
			//service.updateProduct(list.get(i));
		}
		return list;//service.findAll();

	}

}

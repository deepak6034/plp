package com.cg.spring.boot.beans;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Blob;
import java.sql.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="Product")
public class Product implements Serializable{

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	@Column(name="p_name")
	private String name;
	@Column(name="p_companyname")
	private String companyname;
	@Column(name="p_image")
	private Blob image;
	@Column(name="p_price")
	private BigDecimal price;
	@Column(name="p_dateofmanufacturing")
	private Date dateofmanufacturing;
	
    @Column(name="p_type")
	private String type;
	
	@Column(name="m_id")
	private int merchantid;
/*	@Column(name="coupon_id")
	private int couponid;*/
	@Column(name="p_quantity")
	private int quantity;
	
	@Column(name="discount")
	private int discount;
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCompanyname() {
		return companyname;
	}
	public void setCompanyname(String companyname) {
		this.companyname = companyname;
	}
	public Blob getImage() {
		return image;
	}
	public void setImage(Blob image) {
		this.image = image;
	}
	public BigDecimal getPrice() {
		return price;
	}
	public void setPrice(BigDecimal price) {
		this.price = price;
	}
	public Date getDateofmanufacturing() {
		return dateofmanufacturing;
	}
	public void setDateofmanufacturing(Date dateofmanufacturing) {
		this.dateofmanufacturing = dateofmanufacturing;
	}

	public int getMerchantid() {
		return merchantid;
	}
	public void setMerchantid(int merchantid) {
		this.merchantid = merchantid;
	}
	public int getDiscount() {
		return discount;
	}
	public void setDiscount(int discount) {
		this.discount = discount;
	}
	/*public int getCouponid() {
		return couponid;
	}
	public void setCouponid(int couponid) {
		this.couponid = couponid;
	}*/
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	/*public Set<Coupon> getProductCoupons() {
		return productCoupons;
	}
	public void setProductCoupons(Set<Coupon> productCoupons) {
		this.productCoupons = productCoupons;
	}*/
	Product()
	{
		
	}
	public Product(int id, String name, String companyname, Blob image, BigDecimal price, Date dateofmanufacturing,
			String type, int merchantid, int quantity, int discount) {
		super();
		this.id = id;
		this.name = name;
		this.companyname = companyname;
		this.image = image;
		this.price = price;
		this.dateofmanufacturing = dateofmanufacturing;
		this.type = type;
		this.merchantid = merchantid;
		this.quantity = quantity;
		this.discount = discount;
	}
	@Override
	public String toString() {
		return "Product [id=" + id + ", name=" + name + ", companyname=" + companyname + ", image=" + image + ", price="
				+ price + ", dateofmanufacturing=" + dateofmanufacturing + ", type=" + type + ", merchantid="
				+ merchantid + ", quantity=" + quantity + ", discount=" + discount + "]";
	}
	
	
	
	
	
	
}

package com.cg.spring.boot.repository;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cg.spring.boot.beans.Product;

@Repository


public class ProductRepoImpl implements ProductRepoInterface{
	@Autowired
	@PersistenceContext
    EntityManager entityManager; 
	
	@Override
	public List<Product> showProducts() {
		// TODO Auto-generated method stub
		List<Product> list=new ArrayList<>();
		Query q=entityManager.createQuery("from Product");
		list=q.getResultList();
		return list;
	}

	public List<Product> showInvoice(String type) {
		
		System.out.println("----------------------------");
		// TODO Auto-generated method stub
		List<Product> list=new ArrayList<>();
		List<Product> list2=new ArrayList<>();
	Query q=entityManager.createQuery("FROM Product where p_type='"+type+"'");
	//select c from Coupon c join fetch c.discount where c.p_type='"+type+"'
		//Query q1=entityManager.createQuery("FROM Coupon where p_type='"+type+"'"); 
		//select name, price, discount from Product,Coupon where couponid="+couponid
			//	SELECT p.p_name, p.p_price, c.discount from Product p,Coupon c where p.coupon_id='"+couponid+"'and c.coupon_id='"+couponid+"'"
				//select  customerdetails.username,customerdetails.password,customerdetails.aadhar,accountdetails.id from customerdetails,accountdetails where customerdetails.aadhar=accountdetails.aadhar"
		list=q.getResultList();
		//list2= q1.getResultList();
		list2.addAll(list);
		return list2;
	}
	
	
	

}

/*
package com.cg.jpacrud.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.cg.jpacrud.entities.Book;

public class BookDaoImpl implements BookDao {

	private EntityManager entityManager;

	public BookDaoImpl() {
		entityManager = JPAUtil.getEntityManager();
	}
	@Override
	public Book getBookById(int id) {
		Book book = entityManager.find(Book.class, id);
		return book;
	}
    @Override
	public List<Book> getBookByTitle(String title) {
		String qStr = "SELECT book FROM Book book WHERE book.title LIKE :ptitle";
		TypedQuery<Book> query = entityManager.createQuery(qStr, Book.class);
		query.setParameter("ptitle", "%"+title+"%");
		return query.getResultList();
	}
    @Override
	public Long getBookCount() {
		String qStr = "SELECT COUNT(book.id) FROM Book book";
		TypedQuery<Long> query = entityManager.createQuery(qStr,
				Long.class);
		Long count = query.getSingleResult();
		return count;
	}
	@Override
	public List<Book> getAuthorBooks(String author) {
		String qStr = "SELECT book FROM Book book WHERE book.author=:pAuthor";
		TypedQuery<Book> query = entityManager.createQuery(qStr, Book.class);
		query.setParameter("pAuthor", author);
		List<Book> bookList = query.getResultList();
		return bookList;
	}
	@Override
	public List<Book> getAllBooks() {
		Query query = entityManager.createNamedQuery("getAllBooks");
		@SuppressWarnings("unchecked")
		List<Book> bookList = query.getResultList();
		return bookList;
	}
	@Override
	public List<Book> getBooksInPriceRange(double low,double high) {
		String qStr = "SELECT book FROM Book book WHERE book.price between :low and :high";
		TypedQuery<Book> query = entityManager.createQuery(qStr, Book.class);
		query.setParameter("low", low);
		query.setParameter("high", high);
		List<Book> bookList = query.getResultList();
		return bookList;
	}

}

*/
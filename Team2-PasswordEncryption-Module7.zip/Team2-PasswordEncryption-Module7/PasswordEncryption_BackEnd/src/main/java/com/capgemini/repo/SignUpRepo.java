package com.capgemini.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.bean.SignUpBean;

@Repository
public interface SignUpRepo  extends CrudRepository<SignUpBean, String>{

}

package com.capgemini.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.service.ISignUp;

@RestController
public class SignUpController {
	
	
		@Autowired
		ISignUp service;
	
	   @RequestMapping(value = "/newSignUp{email}{psw}{psw_repeat}")
	   void signUp(@RequestParam String email,@RequestParam String psw,@RequestParam String psw_repeat) {

		   	String psw1=service.encrypt(psw);
		   	String psw2=service.encrypt(psw_repeat);
	  	    service.signUp(email, psw1, psw2);
	  	    System.out.println("Added Successfully");
	  	
	  	    }

}

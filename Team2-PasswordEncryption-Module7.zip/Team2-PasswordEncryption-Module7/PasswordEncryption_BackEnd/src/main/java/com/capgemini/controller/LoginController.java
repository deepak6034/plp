package com.capgemini.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.service.ISignUp;

@RestController
public class LoginController {
	
	@Autowired
	ISignUp service;
	
	 @RequestMapping(value = "/login{email}{psw}")
	 public void login(@RequestParam String email,@RequestParam String psw)
	 {
		 String psw1=service.encrypt(psw);
		 boolean b= service.login(email,psw1);
		 if(b)
		 {
			 System.out.print("Login Successfull");
		
		 
		 }
		 else
		 {
			 System.out.println("LoginFailed");
		 }
	 }

}

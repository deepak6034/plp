package com.capgemini.service;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.bean.SignUpBean;
import com.capgemini.repo.SignUpRepo;

@Service
public class SignUpImpl implements ISignUp{

	@Autowired
	SignUpRepo repo;
	
	@Override
	public void signUp(String email, String psw, String psw_repeat) {
		
		
		SignUpBean sign = new SignUpBean();
		if(psw.equals(psw_repeat))
		{
			sign.setEmail(email);
			sign.setPassword(psw);
			repo.save(sign);
		}
		
	}

	@Override
	public String encrypt(String password) {
		
		StringBuilder sb = new StringBuilder();
	    for (char c : password.toCharArray()) {
	    sb.append((int)c);
	    sb.append('*');
	    }
	    
	    return sb.toString();
	    
	    /*String str1=new String(sb);
	    char ch[]=str1.toCharArray();
	    int len=ch.length;
	    StringBuilder sb1=new StringBuilder();
	    StringBuilder sb2=new StringBuilder();
	    for(int i=0;i<len;i++)
	    {
	    	if(ch[i]=='*')
	    	{
	    		
	    		int s=Integer.parseInt(sb1.toString());
	    		char c=(char)s;
	    		
	    		sb2.append(c);
	    		sb1.setLength(0);
	    	}
	    	else {
	    	
	    		sb1.append(ch[i]);
	    	}
	    }
	    
		return password;*/
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean login(String email, String psw) {
		// TODO Auto-generated method stub
		
		SignUpBean bean=repo.findById(email).get();
		if(bean.getPassword().equals(psw))
		{
			return true;
		}
		
		else
			return false;
		
	}

}

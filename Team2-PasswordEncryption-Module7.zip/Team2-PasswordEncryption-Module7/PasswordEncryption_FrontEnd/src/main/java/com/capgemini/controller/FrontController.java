package com.capgemini.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;


import com.capgemini.bean.SignUpBean;



@RestController
public class FrontController {
	
	
	@RequestMapping("/sign_up")
	public SignUpBean signUp(@RequestParam String email,@RequestParam String psw,@RequestParam String psw_repeat) {
		
	RestTemplate rt4=new RestTemplate();
	SignUpBean sign=rt4.getForObject("http://localhost:9092/newSignUp?email="+email+"&psw="+psw+"&psw_repeat="+psw_repeat, SignUpBean.class);
	return sign;

	}
	
	@RequestMapping("/log")
	public SignUpBean logOn(@RequestParam String email,@RequestParam String psw) {
		
	RestTemplate rt4=new RestTemplate();
	SignUpBean log=rt4.getForObject("http://localhost:9092/login?email="+email+"&psw="+psw, SignUpBean.class);
	return log;

	}

	
	

}

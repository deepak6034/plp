package com.capgemini.controller;


import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.capgemini.bean.Password;

@RestController
public class FrontController {

	@RequestMapping("/changePassword")

	public Password changePassword(@RequestParam String pass,@RequestParam String newPass,@RequestParam String confirmPass) {


	RestTemplate rt4=new RestTemplate();
	Password p=rt4.getForObject("http://localhost:9092/update?pass="+pass+"&newPass="+newPass+"&confirmPass="+confirmPass, Password.class);
	return p;

	}

	
	
	
	
}

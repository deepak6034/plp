package com.capgemini.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.bean.Password;
import com.capgemini.repo.PasswordRepo;

@Service
public class PasswordServiceImpl implements IPasswordService {

	@Autowired
	PasswordRepo repo;

	@Override
	public void updatePassword(String pass, String newPass, String confirmPass) {
		// TODO Auto-generated method stub

		Password p = new Password();
		if (newPass.equals(confirmPass)) {
			p.setOld_pass(pass);
			p.setNew_pass(newPass);

			repo.save(p);
		}

	}
}

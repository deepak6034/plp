package com.capgemini.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.bean.Password;

@Repository
public interface PasswordRepo extends CrudRepository<Password, Integer> {
	
}

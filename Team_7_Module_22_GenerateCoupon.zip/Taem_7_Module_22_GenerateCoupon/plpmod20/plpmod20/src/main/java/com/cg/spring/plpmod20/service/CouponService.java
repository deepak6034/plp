package com.cg.spring.plpmod20.service;

import java.io.IOException;

import com.cg.spring.plpmod20.beans.Coupons;

public interface CouponService {

	public void addCoupon(Coupons p) throws ClassNotFoundException, IOException;

}

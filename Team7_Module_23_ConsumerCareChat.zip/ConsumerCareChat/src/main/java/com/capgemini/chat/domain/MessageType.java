package com.capgemini.chat.domain;

public enum MessageType {
	CHAT,
    JOIN,
    LEAVE
}

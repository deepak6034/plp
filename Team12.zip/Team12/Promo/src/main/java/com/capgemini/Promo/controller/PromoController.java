package com.capgemini.Promo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class PromoController {
	
	@RequestMapping("/items")
	public String getPromo() {
		return "items";
	}
	
	@RequestMapping("/promos")
	public String getItem() {
		return "promos";
	}

}

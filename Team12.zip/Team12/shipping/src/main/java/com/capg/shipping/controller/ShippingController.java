package com.capg.shipping.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class ShippingController {

	@RequestMapping("/OrderPlaced")
	public String balle()
	{
		return "OrderPlaced";
	}
	
	@RequestMapping("/Packed")
	public String balleballe()
	{
		return "Packed";
	}
	@RequestMapping("/InTransit")
	public String balleballeballe()
	{
		return "InTransit";
	}
	@RequestMapping("/OutForDelivery")
	public String balleballeballeballe()
	{
		return "OutFordelivery";
	}
	@RequestMapping("/Delivered")
	public String balleballeballeballeballe()
	{
		return "Delivered";
	}
}
